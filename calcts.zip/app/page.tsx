import BondsCalculator from "../calc"

export default function Page() {
  return <BondsCalculator />
}
